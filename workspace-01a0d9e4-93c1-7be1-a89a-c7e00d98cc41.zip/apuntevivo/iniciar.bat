@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo.
echo  ApunteVivo
echo  No cierres esta ventana mientras uses la app.
echo  Se abrira en el navegador: http://127.0.0.1:8765
echo  Usala en Google Chrome o Microsoft Edge.
echo.
start "" cmd /c "ping -n 2 127.0.0.1 >nul & start http://127.0.0.1:8765/"
py -m http.server 8765 --bind 127.0.0.1
if not errorlevel 1 goto :eof
python -m http.server 8765 --bind 127.0.0.1
if not errorlevel 1 goto :eof
python3 -m http.server 8765 --bind 127.0.0.1
if not errorlevel 1 goto :eof
echo.
echo  No encontre Python. Instala Python desde https://www.python.org/downloads/
echo  Marca "Add python.exe to PATH" y vuelve a abrir este archivo.
echo.
pause
