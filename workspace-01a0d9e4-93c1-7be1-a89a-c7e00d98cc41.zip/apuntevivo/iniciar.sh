#!/bin/sh
cd "$(dirname "$0")" || exit 1
echo "ApunteVivo — no cierres esta ventana."
echo "Abriendo http://127.0.0.1:8765 en el navegador."
echo "Usala en Google Chrome o Microsoft Edge."
(sleep 1
  if command -v xdg-open >/dev/null 2>&1; then xdg-open http://127.0.0.1:8765/
  elif command -v open >/dev/null 2>&1; then open http://127.0.0.1:8765/
  fi) &
if command -v python3 >/dev/null 2>&1; then
  exec python3 -m http.server 8765 --bind 127.0.0.1
fi
if command -v python >/dev/null 2>&1; then
  exec python -m http.server 8765 --bind 127.0.0.1
fi
echo "Instala Python 3 y vuelve a intentar."
exit 1
